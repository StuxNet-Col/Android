package com.gsamdev.clase1.data.sqlite.queries

import android.content.Context

class GameQuery(private val context: Context) {

    fun saveWinnerPlay(  ) {

    }
}
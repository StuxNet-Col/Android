package com.gsamdev.clase1.ui.game

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.gsamdev.clase1.R

class TeamPlanningActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_team_planning)
    }
}
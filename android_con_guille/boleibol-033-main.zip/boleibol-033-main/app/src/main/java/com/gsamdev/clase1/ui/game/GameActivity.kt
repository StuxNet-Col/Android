package com.gsamdev.clase1.ui.game

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.gsamdev.clase1.R

class GameActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game)

    }
}
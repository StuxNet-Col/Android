package com.gsamdev.clase1.ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.gsamdev.clase1.R

class RegisterTeamsGameActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register_teams_game)
    }
}
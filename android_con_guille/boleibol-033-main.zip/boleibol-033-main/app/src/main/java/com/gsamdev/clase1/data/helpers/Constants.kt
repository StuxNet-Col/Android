package com.gsamdev.clase1.data.helpers


class Constants {
    companion object {
        const val NAME_DATA_BASE = "DB_PLAY_BOlLEY"
        const val NAME_TABLE_USERS = "tbl_users"
        const val NAME_TABLE_HISTORY_GAMES = "tbl_history_games"
        const val NAME_TABLE_PLAYERS = "tbl_players"
        const val VERSION_DATABASE = 1

    }
}